<?php
if (!file_get_contents('http://php.net')) {
    echo '<p>Отсутствует сетевой доступ<p>';
}
