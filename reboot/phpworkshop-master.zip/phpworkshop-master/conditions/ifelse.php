<?php
$flag = true; // Истина
if ($flag) {
    echo '<p>Переменная flag имеет значение true</p>';
} else {
    echo '<p>Переменная flag имеет значение false</p>';
}
