<?php
if (file_get_contents('http://php.net')) {

} else {
    echo '<p>Отсутствует сетевой доступ<p>';
}
