<?php
$x = -17;
$x = $x < 0 ? -$x : $x;
echo $x; // 17
