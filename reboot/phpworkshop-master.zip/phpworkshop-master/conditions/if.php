<?php
$number = 4;
if ($number == 4) echo 'Число равно 4';