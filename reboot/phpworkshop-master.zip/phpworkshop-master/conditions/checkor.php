<?php
file_get_contents('http://php.net') or exit('Ошибка');
// Дальнейшие операторы
// ...
