<?php
echo "Hello, world!";
?>
