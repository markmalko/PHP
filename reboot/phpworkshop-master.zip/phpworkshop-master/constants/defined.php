<?php
// Определяем константу
define('VALUE', 1);

// Если константа существует, выводим ее значение
if (defined('VALUE')) echo VALUE; // 1
