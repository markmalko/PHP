<?php
// Определяем константу VALUE
define('VALUE', 1);

// Прямое обращение к константе
echo VALUE; // 1
// Получение значение константы через функцию constant()
echo constant('VALUE'); // 1
