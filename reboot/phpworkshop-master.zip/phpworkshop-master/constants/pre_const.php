<?php
echo 'Имя файла ' . __FILE__ . '<br />';
echo 'Строка ' . __LINE__;
