<?php
$i = 0;
do {
    echo "$i<br />";
} while (++$i <= 5);
