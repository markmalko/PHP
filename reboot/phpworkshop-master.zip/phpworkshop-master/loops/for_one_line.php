<?php
for ($i = 5; $i; print $i, print "<br />", $i--);
