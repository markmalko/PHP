<?php
for ($i = 5; $i; $i--) {
    echo "$i<br />";
}
