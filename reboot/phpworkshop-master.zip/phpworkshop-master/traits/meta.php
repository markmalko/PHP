<?php
require_once 'seo.php';
require_once 'opengraph.php';

trait Meta
{
    use Seo, OpenGraph;
}
