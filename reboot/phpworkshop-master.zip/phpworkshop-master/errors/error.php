<?php
$str = 'Hello world!';
$str[] = 4;
