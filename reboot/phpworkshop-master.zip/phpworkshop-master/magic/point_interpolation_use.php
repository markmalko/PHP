<?php
require_once 'point_interpolation.php';

$point = new Point(5, 12);

echo "point = {$point}"; // point = (5, 12)
