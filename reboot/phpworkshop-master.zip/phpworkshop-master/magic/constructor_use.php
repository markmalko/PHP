<?php
require_once 'constructor.php';

$obj = new Constructor();

echo '<pre>';
print_r($obj);
echo '</pre>';
