<?php
require_once('destructor.php');

$obj = new Destructor();
