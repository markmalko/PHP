<?php
echo 6 << 1;   // 12
echo '<br />';
echo 6 << 2;   // 24
echo '<br />';
echo 6 << 10;  // 6144
echo '<br />';
echo 6 << -1;  // 0
echo '<br />';
echo 6 << 31;  // 0
