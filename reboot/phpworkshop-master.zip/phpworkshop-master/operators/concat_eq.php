<?php
$number = 216;
$str = 'Сегодня ';
$str .= $number;
$str .= ' участников';
echo $str;
