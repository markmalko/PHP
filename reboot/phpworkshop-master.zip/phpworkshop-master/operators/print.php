<?php
$number = 216;
print('Сегодня ' . $number . ' участников'); // Сегодня 216 участников
echo print('Hello, world!');    // Hello world!1
// print echo "Hello, world!";  // Ошибка
