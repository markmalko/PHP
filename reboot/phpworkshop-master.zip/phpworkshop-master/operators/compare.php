<?php
echo 1 > 0;              // true
echo 1 > 1;              // false
echo 1 >= 1;             // true
echo 1 < 0;              // false
echo 1 < 1;              // false
echo 1 <= 1;             // true
echo 1 == 0;             // false
echo 1 == 1;             // true
echo 1 != 0;             // true
echo 1 != 1;             // false
echo 0 == '4bfj';        // false
echo 0 == '';            // true
echo 0 == 'hello world'; // true
echo 0 == null;          // true