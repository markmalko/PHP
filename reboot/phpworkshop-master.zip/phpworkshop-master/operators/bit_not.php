<?php
echo ~45;     // -46
echo '<br>';
echo ~92;     // -93
