<?php
$first = $second = 1;
$first = 3;
echo $second; // 1