<?php
class PrivatePoint
{
    public $x;
    private $y;
}
