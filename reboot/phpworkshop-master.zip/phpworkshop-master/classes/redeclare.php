<?php
class Point
{
    public $x;
    public $y;
}

// Fatal error: Cannot redeclare class Point
class Point
{

}
