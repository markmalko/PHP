<?php
// Включение файла
require_once 'point.php';
// Все последующие попытки игнорируются
require_once 'point.php';
require_once 'point.php';
