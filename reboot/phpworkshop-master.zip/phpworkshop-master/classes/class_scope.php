<?php
require 'point.php';
// class Point
// {
//     public $x;
//     public $y;
// }
$point = new Point;
echo $x; // Notice: Undefined variable: x in