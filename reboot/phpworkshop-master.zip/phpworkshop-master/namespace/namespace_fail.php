<!DOCTYPE html>
<html lang="ru">
<head>
  <title>HTML-форма с флажком</title>
  <meta charset='utf-8'>
</head>
<body>
<?php
namespace SelfPhp;

const VERSION = '2.0';

function debug($obj)
{
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
}
?>
</body>
</html>
