<?php
$fst = ['one', 'two'];
$snd = ['three', 'four', 'five'];
$sum = $fst + $snd;
echo '<pre>';
print_r($sum);
echo '</pre>';
