<?php
$var = 'Hello world';
$arr = (array) $var;
echo '<pre>';
print_r($arr);
echo '</pre>';
