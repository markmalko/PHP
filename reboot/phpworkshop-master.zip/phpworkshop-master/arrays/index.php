<?php
$arr = [10 => 'Hello, ', 'world', '!'];
echo '<pre>';
print_r($arr);
echo '</pre>';
