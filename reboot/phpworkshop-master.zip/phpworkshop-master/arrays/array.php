<?php
$arr = array('Hello, ', 'world', '!');
echo $arr[0]; // Hello,
echo $arr[1]; // world
echo $arr[2]; // !
