<?php
$arr = [10 => 'Hello, ', 9 => 'world', '!'];
echo '<pre>';
print_r($arr);
echo '</pre>';
