<?php
$arr = array('Hello, ', 'world', '!');
echo '<pre>';
print_r($arr);
echo '</pre>';
