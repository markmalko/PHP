<?php
$arr = ['one' => '1', 'two' => '2', 'two' => '3'];
echo $arr['one']; // 1
echo '<br />';    // Перевод строки
echo $arr['two']; // 3