<?php
require_once 'derived_overridden.php';

$obj = new Derived();
$obj->overridden();
