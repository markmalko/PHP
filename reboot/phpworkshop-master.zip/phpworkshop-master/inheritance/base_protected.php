<?php
class Base
{
    protected $var;
    public function __construct($var)
    {
        $this->var = $var;
    }
}
