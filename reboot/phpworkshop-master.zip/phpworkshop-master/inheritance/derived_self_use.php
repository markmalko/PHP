<?php
require_once 'derived_self.php';

echo Derived::test(); // Base
