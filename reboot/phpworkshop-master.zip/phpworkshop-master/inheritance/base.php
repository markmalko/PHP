<?php
class Base
{
    public $first;
    public function printFirst()
    {
        echo $this->first;
    }
}
