<?php
require_once 'derived_static.php';

echo Derived::test(); // Derived
