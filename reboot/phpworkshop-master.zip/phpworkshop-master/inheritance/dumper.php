<?php
class Dumper
{
    public static function print($obj)
    {
        print_r($obj);
    }
}
