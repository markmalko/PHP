<?php
require_once 'derived_overridden_alt.php';

$obj = new Derived();
$obj->overridden();
