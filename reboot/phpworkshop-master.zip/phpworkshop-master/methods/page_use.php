<?php
require_once 'page.php';

Page::render();
