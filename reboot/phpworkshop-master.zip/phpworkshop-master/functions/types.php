<?php
function getSum(int $fst, int $snd) : int
{
    return $fst + $snd;
}
echo getSum(2, 2); // 4
echo getSum(2.5, 2.5); // 4
