<?php
function getSum($left = 10, $right)
{
    $sum = $left + $right;
    return $sum;
}
echo getSum(5);