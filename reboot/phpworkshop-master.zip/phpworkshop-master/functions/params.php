<?php
function getSum($left, $right)
{
    $sum = $left + $right;
    return $sum;
}
echo getSum(10, 5); // 15