<?php
function getSum()
{
    $sum = 10 + 5;
    return $sum;
}
echo getSum(); // 15
