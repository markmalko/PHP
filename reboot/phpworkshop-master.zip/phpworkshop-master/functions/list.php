<?php
require_once('return_array.php');
list($bytes, $kbytes, $mbytes, $gbytes) = formatSize(18642678);