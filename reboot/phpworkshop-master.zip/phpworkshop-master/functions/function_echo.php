<?php
function getSum()
{
    $sum = 10 + 5;
    echo $sum; // 15
}
getSum();
