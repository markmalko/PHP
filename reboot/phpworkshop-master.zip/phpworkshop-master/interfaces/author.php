<?php
interface Author
{
    public function setAuthor($authors);
    public function getAuthor();
}
