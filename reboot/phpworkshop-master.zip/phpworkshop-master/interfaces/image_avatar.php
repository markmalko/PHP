<?php
require_once 'image.php';
interface Avatar extends Image {}
