<?php
require_once 'user.php';
class BackendUser extends User {}
