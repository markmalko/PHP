<?php
require_once 'topic.php';
class News extends Topic {}
