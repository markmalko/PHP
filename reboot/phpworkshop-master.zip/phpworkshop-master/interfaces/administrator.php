<?php
require_once 'backenduser.php';
class Administrator extends BackendUser {}
