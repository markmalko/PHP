<?php
require_once 'user.php';
class FrontUser extends User {}
