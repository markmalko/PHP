<?php
$str = 'Здесь может быть любой текст';
echo wordwrap($str, 10, '<br />');
