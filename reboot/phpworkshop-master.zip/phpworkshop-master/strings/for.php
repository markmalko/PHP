<?php
$str = 'Hello';
for($i = 0; $i < strlen($str); $i++) {
    echo $str[$i] . '<br />';
}
