<?php
$red = 255;
$green = 255;
$blue = 100;
printf('#%X%X%X', $red, $green, $blue); // #FFFF64
