<?php
echo chr(36); // $
