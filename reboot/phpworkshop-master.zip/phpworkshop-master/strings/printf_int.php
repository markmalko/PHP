<?php
echo '<pre>';
printf('% 4d\n', 45); // '   45'
printf('%04d\n', 45); // '00045'
echo '</pre>';
