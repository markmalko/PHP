<?php
echo "\u{0410}";
