<?php
echo ord('$'); // 36
