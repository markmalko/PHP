<?php
$number = 5867;
printf('Двоичное число: %b<br />', $number);
printf('Десятичное число: %d<br />', $number);
printf('Число с плавающей точкой: %f<br />', $number);
printf('Восьмеричное число: %o<br />', $number);
printf('Строковое представление: %s<br />', $number);
printf('Шестнадцатеричное число (нижний регистр): %x<br />', $number);
printf('Шестнадцатеричное число (верхний регистр): %X<br />', $number);
