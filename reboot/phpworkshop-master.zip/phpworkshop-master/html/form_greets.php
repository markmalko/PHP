<?php
require('form_greets_handler.php');
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <title>Введите ваше имя</title>
  <meta charset='utf-8'>
</head>
<body>
  <form method='post'>
  <input type='text' name='name'>
  <input type='submit' value='Отправить'>
  </form>
</body>
</html>