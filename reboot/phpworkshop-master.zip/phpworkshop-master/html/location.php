<?php
header('Location: http://php.net');
