<?php
echo $_GET['forum_id'];
