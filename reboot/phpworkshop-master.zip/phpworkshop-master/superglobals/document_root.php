<?php
echo $_SERVER['DOCUMENT_ROOT'];
echo '<br />';
echo __DIR__;
