<?php
{
    echo 5 + 5;
    echo 5 - 2;
    echo "Hello world!";
}
