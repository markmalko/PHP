<!DOCTYPE html>
<html lang="ru">
  <head>
    <title><?php echo "Вывод текущей даты" ?></title>
    <meta charset='utf-8'>
  </head>
  <body>
    <?php
      echo "Текущая дата:<br />";
      echo date(DATE_RSS);
    ?>
  </body>
</html>