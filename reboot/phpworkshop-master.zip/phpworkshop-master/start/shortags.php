<!DOCTYPE html>
<html lang="ru">
  <head>
    <title>Альтернативные теги</title>
    <meta charset='utf-8'>
  </head>
  <body>
    <?= "Hello world!"; ?>
  </body>
</html>