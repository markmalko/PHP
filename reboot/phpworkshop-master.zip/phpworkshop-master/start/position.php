<?php
echo strstr( // эту функцию мы рассмотрим позднее
    "Hello, world", "H");
