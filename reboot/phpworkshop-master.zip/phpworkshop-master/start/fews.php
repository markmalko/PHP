<?php
if(mt_rand(0,1)) {
    ?>
    <div style='color:green'><?= "Истина"; ?></div>
    <?php
} else {
    ?>
    <div style='color:red'><?= "Ложь" ?></div>
    <?php
}