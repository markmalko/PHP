SELECT first_name, last_name FROM users;
