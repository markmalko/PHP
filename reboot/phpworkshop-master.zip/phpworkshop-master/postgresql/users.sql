CREATE TABLE users (
  id SERIAL,
  first_name VARCHAR(40),
  last_name VARCHAR(40)
);